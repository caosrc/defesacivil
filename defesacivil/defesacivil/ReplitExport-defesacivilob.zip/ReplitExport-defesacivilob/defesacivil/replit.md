# Defesa Civil de Ouro Branco — Sistema de Vistorias

## Visão Geral
Sistema web completo de registro e gerenciamento de ocorrências para a Defesa Civil de Ouro Branco (MG).

## Arquitetura
- **Frontend**: React 19 + TypeScript + Vite (porta 5000)
- **Backend**: Express.js API REST (porta 3001)
- **Banco de Dados**: Replit PostgreSQL (DATABASE_URL)
- **Mapa**: React-Leaflet com OpenStreetMap
- **Exportação**: KMZ via JSZip

## Estrutura
```
/
├── server/
│   └── index.js          # API Express (porta 3001)
├── src/
│   ├── App.tsx            # App principal — lista + mapa
│   ├── App.css            # Estilos — tema azul/laranja Defesa Civil
│   ├── types.ts           # Tipos TypeScript + constantes (naturezas, ícones, cores)
│   ├── api.ts             # Funções de fetch para a API
│   └── components/
│       ├── NovaOcorrencia.tsx     # Formulário completo de registro
│       ├── MapaOcorrencias.tsx    # Mapa Leaflet com marcadores coloridos
│       └── DetalheOcorrencia.tsx  # Modal de detalhe + exportar KMZ individual
├── vite.config.ts         # Proxy /api → localhost:3001
└── package.json
```

## Workflows
- **Start application**: `npm run dev` → porta 5000 (webview)
- **Backend API**: `npm run server` → porta 3001 (console)

## Banco de Dados — Tabela `ocorrencias`
| Campo | Tipo | Descrição |
|---|---|---|
| id | SERIAL | Chave primária |
| tipo | VARCHAR(50) | Vistoria, Diligência, Apoio, Outro |
| natureza | VARCHAR(150) | Tipo de natureza (Árvore, Incêndio, etc.) |
| subnatureza | TEXT | Detalhe condicional (estrutura ou animal) |
| nivel_risco | VARCHAR(10) | baixo, medio, alto |
| status_oc | VARCHAR(20) | ativo, resolvido |
| fotos | TEXT[] | Array de base64 |
| lat | DOUBLE PRECISION | Latitude GPS |
| lng | DOUBLE PRECISION | Longitude GPS |
| endereco | TEXT | Endereço manual |
| proprietario | VARCHAR(200) | Nome do proprietário/morador |
| observacoes | TEXT | Texto livre |
| created_at | TIMESTAMP | Data/hora automática |

## Funcionalidades
- Formulário com 9 campos (tipo → natureza → subnatureza condicional → nível → status → fotos → GPS/endereço → proprietário → observações)
- Mapa OpenStreetMap centrado em Ouro Branco com marcadores por tipo (emoji + cor)
- Popup no marcador com botão "Ver detalhes"
- Modal de detalhe com exportação KMZ individual
- Exportação KMZ global de todas as ocorrências com GPS
- Filtros por nível, status e busca de texto
- Resumo numérico no topo (Alto, Médio, Baixo, Total)
